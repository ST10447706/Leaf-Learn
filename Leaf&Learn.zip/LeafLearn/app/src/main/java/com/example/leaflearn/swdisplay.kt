package com.example.leaflearn

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity


class swdisplay : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_swdisplay)


        findViewById<TextView>(R.id.sixweekscourse)
        findViewById<ImageView>(R.id.logoimage)
        findViewById<TextView>(R.id.logotext)
        findViewById<TextView>(R.id.display).setOnClickListener {
            fun main() {

                val courseNames = arrayOf("Child Minding", "Cooking", "Garden Maintenance")
                val courseDescriptions = arrayOf(
                    "This course covers the needs of children from birth to six years old, focusing on developmental stages, educational toys, and effective care techniques. Participants will learn how to create a safe and engaging environment for children.",
                    "Participants will explore nutritional requirements, learn about various types of proteins, carbohydrates, and vegetables, and develop skills in meal planning and preparation. The course emphasizes healthy cooking practices and budgeting for meals.",
                    "This course teaches participants about water restrictions and the specific watering needs of different plants, pruning techniques, propagation methods, and planting techniques for various plant types. Participants will gain hands-on experience in maintaining a healthy garden."
                )
                val coursePurposes = arrayOf(
                    "To provide basic child and baby care skills.",
                    "To teach participants how to prepare and cook nutritious family meals.",
                    "To provide basic knowledge of watering, pruning, and planting in domestic gardens."
                )
                val coursePrices = arrayOf("R750.00", "R750.00", "R750.00")

                // Displaying course information
                for (i in courseNames.indices) {
                    println("Course Name: ${courseNames[i]}")
                    println("Description: ${courseDescriptions[i]}")
                    println("Purpose: ${coursePurposes[i]}")
                    println("Price: ${coursePrices[i]}")
                    println()
                }
            }
        }


        }
    }
