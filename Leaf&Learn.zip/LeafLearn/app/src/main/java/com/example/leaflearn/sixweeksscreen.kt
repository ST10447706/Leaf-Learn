package com.example.leaflearn

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity


class sixweeksscreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_sixweeksscreen2)


        findViewById<ImageView>(R.id.cookingimage)
        findViewById<ImageView>(R.id.gardenimage)
        findViewById<ImageView>(R.id.childmindingtext)
        findViewById<Button>(R.id.view).setOnClickListener {
            val intent = Intent(this, swdisplay::class.java)
            startActivity(intent)
        }

        }



    }
