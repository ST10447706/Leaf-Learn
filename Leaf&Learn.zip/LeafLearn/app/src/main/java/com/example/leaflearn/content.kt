package com.example.leaflearn

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import  android.widget.TextView
import android.widget.ImageView
import android.content.Intent


class content : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)

        findViewById<TextView>(R.id.slogan)
        findViewById<TextView>(R.id.logotext)

        findViewById<ImageView>(R.id.logo)

        findViewById<ImageView>(R.id.sixmonths)

        findViewById<Button>(R.id.sixmonthbutton).setOnClickListener {

            val intent = Intent(this@content, sixmonthsscreen::class.java)
            startActivity(intent)
            finish()
        }
    }
}





