package com.example.leaflearn

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class Splash : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_splash)

        findViewById< TextView>(R.id.splashtext)
        val imageView: ImageView = findViewById(R.id.splashimage)

        imageView.alpha = 0f
        imageView.animate().setDuration(1500).alpha(1f).withEndAction {

            val intent = Intent(this, content::class.java) //
            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }
    }
}
