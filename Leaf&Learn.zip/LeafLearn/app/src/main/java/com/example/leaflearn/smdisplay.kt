package com.example.leaflearn

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity


class smdisplay : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_smdisplay)


           findViewById<ImageView>(R.id.logoimage)
        findViewById<Button>(R.id.sixweeksbutton)

        findViewById<TextView>(R.id.smtext)

        fun main() {
            // Parallel arrays for course details
            val courseNames = arrayOf("First Aid", "Sewing", "Landscaping", "Life Skills")
            val descriptions = arrayOf(
                "This course covers essential topics like managing wounds and bleeding, treating burns and fractures, emergency scene management, and performing Cardiopulmonary Resuscitation (CPR). Participants will also learn how to respond to respiratory distress, including choking and blocked airways, equipping them with vital skills for emergency situations.",
                "Participants will explore various sewing techniques, including types of stitches, threading a sewing machine, and sewing buttons, zips, hems, and seams. The course will also cover alterations and the design and creation of new garments, enabling participants to offer valuable sewing services.",
                "This course focuses on identifying indigenous and exotic plants and trees, creating fixed structures like fountains and benches, and understanding the balance of plants and trees in a garden. Participants will also learn about the aesthetics of plant shapes and colors, as well as effective garden layout techniques.",
                "Participants will gain knowledge in opening bank accounts, understanding basic labor laws, and improving their reading, writing, and numeric literacy. This course aims to empower individuals with the practical skills needed for everyday life."
            )
            val purposes = arrayOf(
                "To provide first aid awareness and basic life support skills.",
                "To provide alterations and new garment tailoring services.",
                "To provide skills for landscaping services for new and established gardens.",
                "To provide essential skills for navigating basic life necessities."
            )
            val prices = arrayOf(1500, 1500, 1500, 1500)

            // Example: Print out the course details
            for (i in courseNames.indices) {
                println("Course Name: ${courseNames[i]}")
                println("Description: ${descriptions[i]}")
                println("Purpose: ${purposes[i]}")
                println("Price: R${prices[i]}")
                println()
            }
        }



        findViewById<Button>(R.id.sixweeksbutton).setOnClickListener {
            val intent = Intent(this, sixweeksscreen::class.java)
            startActivity(intent)
        }
    }
}



