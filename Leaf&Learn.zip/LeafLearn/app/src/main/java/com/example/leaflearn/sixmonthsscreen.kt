package com.example.leaflearn

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent


class sixmonthsscreen : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_sixmonthsscreen)

   findViewById<ImageView>(R.id.firstaidImage)
        findViewById<ImageView>(R.id.landscapingImage)
        findViewById<ImageView>(R.id.sewing)
        findViewById<ImageView>(R.id.lifeskillsImage)

    findViewById<Button>(R.id.smButton).setOnClickListener {
            val intent = Intent(this, smdisplay::class.java)
            startActivity(intent)
        }
        }
    }
